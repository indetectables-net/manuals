-------------------------------------------------------------------------
                            Dana Text Editor
                                                              ver1.14.04
                                                     RimArts, Inc. ,2001
-------------------------------------------------------------------------

Changes from ver1.14.03
- Bug fix: Tag jump did not work when ':' was found right before the file
  name.
- Bug fix: STATE_AFTER_NEW callback was not called.

Changes from ver1.14.02
- Bug fix: The program abnormally terminated sometimes when Word
  Backspace or Word Delete was processed.
- Bug fix: The program abnormally terminated sometimes when Help file is
  being open.

Changes from ver1.14.01

- Bug fix: Keyboard macro did not record the beginning of the selection.
- Bug fix: When '\' was specified for replace, the program freezed.
- Bug fix: When a macro that includes cursor up or down was executed
  consecutively, it skipped processing some lines.
- Bug fix: When all MDI windows are minimized, Find or Replace for all
  files did not work correctly.
- Bug fix: F1 key always brought up Help when no file is opened, even if
  other function is assigned to F1.
- Bug fix: When a new file was opened immediately after the Grep result
  (Output) window was closed, this window had the same attributes as the
  Output window. (double click to tag jump).
- Bug fix: When cursor was moved by mouse right after box copy/cut, the
  box selection mode was not disengaged.


Changes from ver1.14.00

- Bug fix: Undo did not work properly in overwrite mode when the text
  contain tabs.

Changes from ver1.13

- Supported Unicode and UTF-8 text.
- A lot of bug fixes.

Changes from ver1.12

- Bug fix: Abnormally terminated when the file which contains ".lzh" in
  the middle of the file name is opened.
- Showing Vertical/Horizontal scroll bar options. Those options were removed
  in ver1.12 but they came back.

Changes from ver1.11
- Bug fix: Could not open the file whose pass name is longer than 128.
- Bug fix: Comment blocks were not colored correctly in the case when
  long lines are wrapped without return codes.
- Bug fix: Some minor bugs in Dana Script.
- etc.


------------ Ver1.10 -------------------------------------
* Important

- Compatibility

  From this version, you can no more use Dana on Windows3.1 with Win32s
  nor WindowsNT3.5 or older. If you have to use those OS, don't upgrade
  please. We are sorry but the world of Windows doesn't allow us  to
  keep those compatibilities and to keep up the new technologies at a
  same time.
  Please run the new Dana on Windows95 or NT4.0, at least NT3.51. (We
  haven't tested on NT3.51 but it may work)


- Installation

  If you are already using Dana.ver1.04 or older, we recommend you to
  setup this new version to a new folder, not the folder old version is
  installed.
  You could overwrite the old folder so that all the setting will be
  inherited, but in that case, WE STRONGLY RECOMMEND YOU TO BACKUP ALL
  FILES IN THE OLD FOLDER BEFORE YOU OVERWRITE THEM. Because sometimes
  old data files make the new version crash because of some compatibility
  problem.
  We tried to remove all that kind of risk as possible as we could. But
  each user's setting varies so we could not remove all the potential
  problems.

- HTML support

  You could see HTML tags in different color in the old version. In the
  new version, you can, too. But if you overwrite the new version
  to the old version, it doesn't work. You will need some work to make
  it effective. You need to configure "Block Comments" setting in the
  "Keywords" property.
  First, select HTML keywords in the combobox in
  "Tool"->"Preferences"->"Keywords". Then click "Block Comments" button
  to configure the block comments.
  Add the following settings.

	Begin:"<"
	End:">"
	Color:whatever you want,
	Keywords in Block:Color
	Click "Add"

	Begin:"<!--"
	End:"-->"
	Color:whatever you want
	Keywords in Block:none
	Click "Add"

	Begin:"<SCRIPT"
	End:"</SCRIPT>"
	Color:whatever you want,
	Keywords in Block:Color
	Click "Add"


- Changes on Dana Script

  You can't pass static string to user defined procedures any more. This
  change may affect some old script including "Michelle.das".
  Please modify those scripts as follows:

    Proc MyProc
        'st$ is declared as a global variable outside the routine
        MyFunc(st$) '<-Error!!
    End Proc

    Proc MyProc
        Dim d$
        d$ = st$ '<- Copy to the local variable like this
        MyFunc(d$)
    End Proc

  Other than that,Dana Scripts has some changes in specification. If you
  find some old scripts don't work. Please check the DanaScr.hlp.

* New features

- Bookmark listing dialog is improved. You don't have to open and close
  the dialog everytime you want to see the list. It will stay resident
  as the part of the frame window. And you have multiple indent levels
  on marked lines.
- Spell checker is integrated finally. Dana incorporates WinterTree
  Software's "Sentry Spell Checker" engine.
- Real word wrapping is supported. Sorry, it should have been supported
  earlier.
- Auto Formatting mode is further improved. It was originally called
  "Word Wrap" mode, but it has changed the name because real word
  wrapping is supported.
- You can specify file types when you create new files.
- "Stay Resident" mode is supported.
- Colored block comment like /**/ in C language is now supported. You
  can define your custom comment blocks.
- And a lot lot more!!


