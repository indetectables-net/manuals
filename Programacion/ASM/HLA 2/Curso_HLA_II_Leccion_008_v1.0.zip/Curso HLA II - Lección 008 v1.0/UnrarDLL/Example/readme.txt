All samples except C sample (UnRDLL.c) are contributed by unrar.dll users.
We at rarlab.com created and tested only UnRDLL.c sample.
