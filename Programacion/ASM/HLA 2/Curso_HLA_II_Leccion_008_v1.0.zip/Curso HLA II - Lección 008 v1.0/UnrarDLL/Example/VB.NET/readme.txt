Unpack and open UnRARNET.sln - includes a wrapper for UnRAR.dll and a test program.
I haven't tried it, but I do not believe this will work with with .NET Framework 1.0.

If you find any problems, I'd appreciate an email.

marcel_madonna@ajmsoft.com