Here you can find 64 bit version of unrar.dll.
