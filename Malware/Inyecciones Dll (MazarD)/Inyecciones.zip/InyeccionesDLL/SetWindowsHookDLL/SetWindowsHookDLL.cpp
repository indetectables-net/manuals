/*Inyecci�n por SetWindowsHookEx
  by MazarD
  http://www.mazard.info
  mazard@gmail.com
*/

#include "setwindowshookex.h"

extern "C"

LRESULT CALLBACK FunHook(int nCode,WPARAM wParam,LPARAM lParam)
{
	if (nCode==HCBT_SETFOCUS)
	{
		LoadLibrary("c:\\ladll.dll");
	}
	return 0;
}