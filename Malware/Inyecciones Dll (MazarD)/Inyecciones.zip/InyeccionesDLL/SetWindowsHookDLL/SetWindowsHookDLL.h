/*Inyecci�n por SetWindowsHookEx
  by MazarD
  http://www.mazard.info
  mazard@gmail.com
*/
#include <windows.h>
extern "C"
{
	LRESULT CALLBACK FunHook(int nCode,WPARAM wParam,LPARAM lParam);
}