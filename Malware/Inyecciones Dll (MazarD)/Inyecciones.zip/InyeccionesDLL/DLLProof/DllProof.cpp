/*Dll de pruebas
  Esta dll es la que inyectaremos en todas nuestras t�cnicas 
  debes ponerla como c:\ladll.dll cada vez que sea ejecutado
  su c�digo y por tanto hemos sido inyectados se crea una nueva
  l�nia con el nombre del ejecutable que nos ha lanzado en c:\dllinyectada.txt

  by MazarD
  http://www.mazard.info
  mazard@gmail.com
*/

#include <windows.h>
#include <stdio.h>

bool WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
	FILE *fitx;
	char nout[MAX_PATH]="";
	if (fdwReason==DLL_PROCESS_ATTACH)
	{
		fitx=fopen("c:\\dllinyectada.txt","a");
		GetModuleFileName(NULL,nout,MAX_PATH);
		fputs("Inyectado en ",fitx);
		fputs(nout,fitx);
		fputs("\n",fitx);
		fclose(fitx);
	}
	return TRUE;
}