/*Inyecci�n por SetWindowsHookEx
  by MazarD
  http://www.mazard.info
  mazard@gmail.com
*/

#include <stdio.h>
#include <windows.h>

int main()
{
	HMODULE dll;
	typedef long (__stdcall *tipoproc)(int,unsigned int,long);
	HWND hWin;
	tipoproc proc;

	dll=LoadLibrary("c:\\dllhook.dll");
	proc=(tipoproc)GetProcAddress(dll,"FunHook");
	printf("%d",SetWindowsHookEx(WH_CBT,proc,dll,0));
	return 0;
}