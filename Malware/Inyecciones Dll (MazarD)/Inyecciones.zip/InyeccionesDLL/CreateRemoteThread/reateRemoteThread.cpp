/*Inyecci�n por CreateRemoteThread
  by MazarD
  http://www.mazard.info
  mazard@gmail.com
*/

#include <windows.h>
int main()
{
	DWORD pid;
	HANDLE proc;
	char buf[MAX_PATH]="";
	char laDll[]="c:\\ladll.dll";
	LPVOID RemoteString;
	LPVOID nLoadLibrary;
	char Entrada[255];

	printf("Ejemplo CreateRemoteThread by MazarD\nhttp://www.mazard.info\n");
	printf("Introduce el PID del programa (puedes verlos en el taskmanager):");
	fgets(Entrada,255,stdin);
	pid=(DWORD)atoi(Entrada);

	proc = OpenProcess(PROCESS_ALL_ACCESS, false, pid);

	//Aqu� usamos directamente GetModuleHandle en lugar de loadlibrary ya que kernel32 la cargan todos los ejecutables
	//Con esto tenemos un puntero a LoadLibraryA
	nLoadLibrary = (LPVOID)GetProcAddress(GetModuleHandle("kernel32.dll"), "LoadLibraryA");

	//Reservamos memoria en el proceso abierto
	RemoteString = (LPVOID)VirtualAllocEx(proc,NULL,strlen(laDll),MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
	//Escribimos el nombre de la dll en la memoria reservada del proceso remoto
	WriteProcessMemory(proc,(LPVOID)RemoteString,laDll,strlen(laDll),NULL);
	//Lanzamos el hilo remoto en loadlibrary pasandole la direcci�n de la cadena
	CreateRemoteThread(proc,NULL,NULL,(LPTHREAD_START_ROUTINE)nLoadLibrary,(LPVOID)RemoteString,NULL,NULL);   

	CloseHandle(proc);

   return true;
}