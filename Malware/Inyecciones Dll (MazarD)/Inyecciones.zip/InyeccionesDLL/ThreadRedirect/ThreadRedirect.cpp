/*Inyecci�n por ThreadRedirect
  Ideado e implementado por MazarD
  http://www.mazard.info
  mazard@gmail.com
*/

#include <windows.h>
#include <stdio.h>

BYTE* CrearCodigo(DWORD Eip,DWORD Ruta,DWORD dLoadLibrary)
{
	BYTE *codeBuff;

	codeBuff=(BYTE*)malloc(22);
	//push eipvella
	*codeBuff=0x68;
	codeBuff++;
	*((DWORD*)codeBuff)=Eip;
	codeBuff+=4;

	*codeBuff=0x9C; //pushfd
	codeBuff++;
	*codeBuff=0x60;  //pushad
	codeBuff++;

	//push path
	*codeBuff=0x68;
	codeBuff++;
	*((DWORD*)codeBuff)=Ruta;
	codeBuff+=4;

	//mov eax,nLoadLib
	*codeBuff=0xB8;
	codeBuff++;
	*((DWORD*)codeBuff)=dLoadLibrary;
	codeBuff+=4;

	*((WORD*)codeBuff)=0xD0FF; //call eax
	codeBuff+=2;
	*codeBuff=0x61; //popad
	codeBuff++;
	*codeBuff=0x9D;  //popfd
	codeBuff++;
	*codeBuff=0xC3;   //ret
	codeBuff-=21;

	return codeBuff;
}
int main()
{
	typedef HANDLE (__stdcall *openthread) (DWORD,BOOL,DWORD);
	openthread AbrirHilo;

	HANDLE proces,fil;
	char nomDll[]="c:\\ladll.dll";
	void *medkitsite,*path;
	DWORD pID,tID;
	BYTE *medicina;

	CONTEXT context;
	DWORD eipvella;
	DWORD nLoadLib;

	printf("Inyecci�n Dll por MazarD\n M�todo Thread Redirection\nhttp://www.mazard.info\n");
	printf("Identificador del proceso (PID):");
	scanf("%d",&pID);
	printf("Identificador del hilo (TID):");
	scanf("%d",&tID);

	printf("Inyectando en el hilo %.2x del proceso %.2x\n",tID,pID);

	//Abrimos el proceso
	proces=OpenProcess(PROCESS_ALL_ACCESS,false,pID);
	if (proces==NULL)
	{
		printf("Error al abrir el proceso, PID incorrecto?");
		return -1;
	}

	//Abrimos el hilo (Est� as� porque el api OpenThread no aparece en mi windows.h)
	AbrirHilo=(openthread)GetProcAddress(GetModuleHandle("kernel32.dll"),"OpenThread");
	fil=AbrirHilo(THREAD_ALL_ACCESS,false,tID);
	if (fil==NULL)
	{
		printf("Error al abrir el hilo, TID incorrecto?");
		return -1;
	}

	//Reservamos mem�ria en el proceso y escribimos la ruta a la dll
	path=VirtualAllocEx(proces,NULL,strlen(nomDll)+1,MEM_COMMIT | MEM_RESERVE,PAGE_READWRITE);
	if (path==NULL)
	{
		printf("Error al reservar memoria, para la ruta");
		return -1;
	}
	if (WriteProcessMemory(proces,path,nomDll,strlen(nomDll),NULL)==0)
	{
		printf("Error al escribir en memoria, para la ruta");
		return -1;
	}


	//Cogemos la direcci�n a LoadLibrary
	nLoadLib=(DWORD)GetProcAddress(GetModuleHandle("kernel32.dll"),"LoadLibraryA");
	if (nLoadLib==NULL)
	{
		printf("Error al coger la direcci�n de LoadLibraryA");
		return -1;
	}
	//Suspendemos el hilo y cogemos el puntero de instrucciones (punto de ejecuci�n actual)
	SuspendThread(fil);
	context.ContextFlags=CONTEXT_CONTROL;
	GetThreadContext(fil,&context);
	eipvella=context.Eip;
	printf("Eip al retornar:%.2x\n",eipvella);
	
	//Creamos el c�digo a partir de eip, la ruta a la dll y la direcci�n de loadlibrary
	medicina=CrearCodigo((DWORD)eipvella,(DWORD)path,nLoadLib);
	printf("CodigoCreado:%.2x\n\n",medicina);

	//Reservamos memoria y escribimos nuestro c�digo en el
	medkitsite=VirtualAllocEx(proces,NULL,22,MEM_COMMIT | MEM_RESERVE,PAGE_EXECUTE_READWRITE);
	if (medkitsite==NULL)
	{
		printf("Error al reservar memoria, para el codigo");
		return -1;
	}
	if (WriteProcessMemory(proces,medkitsite,medicina,22,NULL)==0)
	{
		printf("Error al escribir en memoria,, para el codigo");
		return -1;
	}

	printf("Nuevo Eip:%.2x\n",(DWORD)medkitsite);
	//modificamos el puntero de instrucciones para que apunte a nuestro c�digo inyectado
	//context.Eip = (DWORD)medkitsite;
	//context.ContextFlags = CONTEXT_CONTROL; 
	//SetThreadContext(fil,&context);
	
	//Le decimos al hilo que puede volver a ejecutarse (lanzar� nuestro codigo)
	ResumeThread(fil);
	printf("Inyecci�n completada!!\n");

	CloseHandle(proces);
	CloseHandle(fil);

	return 0;
}